import google.generativeai as genai
import os
import json

from dotenv import load_dotenv

load_dotenv()

genai.configure(
    api_key=os.getenv("GEMINI_API_KEY")
)

model = genai.GenerativeModel(
    "gemini-2.5-flash"
)


def review_proposal(text):

    prompt = f"""
Anda adalah Proposal Review Assistant.

Analisis proposal kegiatan berikut.

Tugas:

1. Nilai konsistensi isi proposal (0-100)
2. Nilai kualitas bahasa formal (0-100)
3. Berikan review singkat
4. Berikan saran perbaikan

WAJIB kembalikan JSON VALID SAJA.

Format:

{{
    "consistency_score": 85,
    "language_score": 90,
    "review": "isi review",
    "suggestions": [
        "saran 1",
        "saran 2",
        "saran 3"
    ]
}}

Proposal:

{text}
"""

    try:

        response = model.generate_content(prompt)

        result_text = response.text.strip()

        # Membersihkan jika Gemini memberi ```json
        result_text = result_text.replace(
            "```json",
            ""
        )

        result_text = result_text.replace(
            "```",
            ""
        )

        result = json.loads(result_text)

        return result

    except Exception as e:

        return {
            "consistency_score": 0,
            "language_score": 0,
            "review": f"Gagal menganalisis proposal: {e}",
            "suggestions": []
        }