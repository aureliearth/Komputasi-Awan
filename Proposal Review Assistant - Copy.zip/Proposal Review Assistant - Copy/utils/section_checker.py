import re

REQUIRED_SECTIONS = {
    "Latar Belakang": [
        "latar belakang",
        "latar",
        "belakang"
    ],
    "Tujuan": [
        "tujuan"
    ],
    "Sasaran": [
        "sasaran",
        "target peserta",
        "peserta"
    ],
    "Susunan Acara": [
        "susunan acara",
        "rundown",
        "jadwal"
    ],
    "Anggaran": [
        "anggaran",
        "rab",
        "rencana anggaran"
    ],
    "Penutup": [
        "penutup"
    ]
}


def normalize(text):
    """
    ubah semua jadi format bersih
    """
    text = text.lower()
    text = re.sub(r'\s+', ' ', text)  # gabung spasi/enter
    return text


def check_sections(text):

    text = normalize(text)

    found = []
    missing = []

    for section, keywords in REQUIRED_SECTIONS.items():

        matched = False

        for keyword in keywords:
            if keyword in text:
                matched = True
                break

        if matched:
            found.append(section)
        else:
            missing.append(section)

    return {
        "found": found,
        "missing": missing
    }


def calculate_completeness_score(result):

    total = len(REQUIRED_SECTIONS)
    found = len(result["found"])

    return round((found / total) * 100)


def generate_section_report(result):

    report = "## HASIL CEK KELENGKAPAN\n\n"

    report += "### Section Ditemukan\n"
    for i in result["found"]:
        report += f"✅ {i}\n"

    report += "\n### Section Belum Ada\n"
    for i in result["missing"]:
        report += f"❌ {i}\n"

    return report