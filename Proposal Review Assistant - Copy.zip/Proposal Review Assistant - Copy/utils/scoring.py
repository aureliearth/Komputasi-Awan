def calculate_final_score(
    completeness_score,
    budget_score,
    consistency_score,
    language_score
):
    """
    Menghitung skor akhir berdasarkan bobot
    """

    weights = {
        "completeness": 0.35,
        "budget": 0.20,
        "consistency": 0.20,
        "language": 0.25
    }

    final_score = (
        completeness_score * weights["completeness"] +
        budget_score * weights["budget"] +
        consistency_score * weights["consistency"] +
        language_score * weights["language"]
    )

    return round(final_score)


def get_grade(score):
    """
    Konversi skor ke grade
    """

    if score >= 85:
        return "A"

    elif score >= 70:
        return "B"

    elif score >= 55:
        return "C"

    elif score >= 40:
        return "D"

    else:
        return "E"


def get_category(score):
    """
    Kategori kualitas proposal
    """

    if score >= 85:
        return "Sangat Baik"

    elif score >= 70:
        return "Baik"

    elif score >= 55:
        return "Cukup"

    elif score >= 40:
        return "Kurang"

    else:
        return "Perlu Revisi Besar"


def generate_score_report(
    completeness_score,
    budget_score,
    consistency_score,
    language_score,
    final_score
):
    """
    Membuat laporan skor
    """

    report = f"""
## HASIL PENILAIAN

### Detail Skor

📄 Kelengkapan Proposal : {completeness_score}/100

💰 Anggaran : {budget_score}/100

🔍 Konsistensi : {consistency_score}/100

✍️ Bahasa Formal : {language_score}/100

---

### Skor Akhir

🏆 Nilai Akhir : {final_score}/100

📊 Grade : {get_grade(final_score)}

⭐ Kategori : {get_category(final_score)}
"""

    return report