import re


def extract_currency(text):
    """
    Mengambil semua nominal rupiah dari proposal
    Contoh:
    Rp 50.000
    Rp50.000
    Rp 1.250.000
    """

    pattern = r'Rp\s*([\d\.]+)'

    matches = re.findall(pattern, text, re.IGNORECASE)

    values = []

    for value in matches:
        try:
            value = int(value.replace(".", ""))
            values.append(value)
        except:
            pass

    return values


def analyze_budget(text):
    """
    Analisis sederhana terhadap RAB
    """

    values = extract_currency(text)

    result = {
        "budget_found": False,
        "total_items": 0,
        "total_budget": 0,
        "warnings": []
    }

    if len(values) > 0:
        result["budget_found"] = True
        result["total_items"] = len(values)
        result["total_budget"] = sum(values)

    # Warning jika tidak ada anggaran
    if not result["budget_found"]:
        result["warnings"].append(
            "Bagian anggaran atau nominal rupiah tidak ditemukan."
        )

    # Warning jika item terlalu sedikit
    elif result["total_items"] < 3:
        result["warnings"].append(
            "Jumlah item anggaran sangat sedikit. Pastikan RAB sudah lengkap."
        )

    return result


def calculate_budget_score(result):
    """
    Skor anggaran sederhana
    """

    score = 100

    if not result["budget_found"]:
        score -= 60

    if result["total_items"] < 3:
        score -= 20

    return max(score, 0)


def generate_budget_report(result):
    """
    Membuat laporan analisis anggaran
    """

    report = "## HASIL ANALISIS ANGGARAN\n\n"

    report += f"💰 Total Nominal Terdeteksi: Rp {result['total_budget']:,}\n\n"

    report += f"📋 Jumlah Item Anggaran: {result['total_items']}\n\n"

    if result["warnings"]:
        report += "### Peringatan\n"

        for warning in result["warnings"]:
            report += f"⚠️ {warning}\n"

    else:
        report += "✅ Tidak ditemukan masalah pada anggaran.\n"

    return report