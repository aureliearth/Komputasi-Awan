import streamlit as st

# Reader
from utils.pdf_reader import read_pdf
from utils.docx_reader import read_docx

# Analysis
from utils.section_checker import (
    check_sections,
    calculate_completeness_score,
    generate_section_report
)

from utils.budget_checker import (
    analyze_budget,
    calculate_budget_score,
    generate_budget_report
)

from utils.scoring import (
    calculate_final_score,
    generate_score_report,
    get_category
)

from utils.gemini_review import review_proposal


# =========================
# CONFIG
# =========================

st.set_page_config(
    page_title="Proposal Review Assistant",
    page_icon="📄",
    layout="wide"
)

# =========================
# HEADER
# =========================

st.title("📄 Proposal Review Assistant")

st.markdown("""
Upload proposal kegiatan dalam format **PDF** atau **DOCX**.

Sistem akan:

✅ Mengecek kelengkapan proposal  
✅ Menganalisis anggaran  
✅ Menilai konsistensi isi  
✅ Memberikan saran bahasa formal menggunakan Gemini AI  
✅ Memberikan skor kualitas proposal
""")

st.divider()

# =========================
# UPLOAD FILE
# =========================

uploaded_file = st.file_uploader(
    "Upload Proposal",
    type=["pdf", "docx"]
)

# =========================
# PROCESS FILE
# =========================

if uploaded_file:

    extension = uploaded_file.name.split(".")[-1].lower()

    try:

        if extension == "pdf":
            proposal_text = read_pdf(uploaded_file)

        elif extension == "docx":
            proposal_text = read_docx(uploaded_file)

        else:
            st.error("Format file tidak didukung.")
            st.stop()

    except Exception as e:
        st.error(f"Gagal membaca file: {e}")
        st.stop()

    # =========================
    # PREVIEW
    # =========================

    st.subheader("📖 Preview Proposal")

    st.text_area(
        "Isi Dokumen",
        proposal_text[:5000],
        height=300
    )

    # =========================
    # BUTTON ANALISIS
    # =========================

    if st.button("🔍 Analisis Proposal", use_container_width=True):

        with st.spinner("Sedang menganalisis proposal..."):

            # ====================================
            # SECTION ANALYSIS
            # ====================================

            section_result = check_sections(
                proposal_text
            )

            completeness_score = (
                calculate_completeness_score(
                    section_result
                )
            )

            section_report = (
                generate_section_report(
                    section_result
                )
            )

            # ====================================
            # BUDGET ANALYSIS
            # ====================================

            budget_result = analyze_budget(
                proposal_text
            )

            budget_score = (
                calculate_budget_score(
                    budget_result
                )
            )

            budget_report = (
                generate_budget_report(
                    budget_result
                )
            )

            # ====================================
            # GEMINI REVIEW
            # ====================================

            ai_result = review_proposal(
                 proposal_text
                 )
            consistency_score = ai_result[
                 "consistency_score"
                 ]
            language_score = ai_result[
                "language_score"
                ]

            # ====================================
            # FINAL SCORE
            # ====================================

            final_score = (
                calculate_final_score(
                    completeness_score,
                    budget_score,
                    consistency_score,
                    language_score
                )
            )

        # =========================
        # DASHBOARD
        # =========================

        st.success("Analisis selesai!")

        st.subheader("📊 Dashboard Penilaian")

        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric(
                "Kelengkapan",
                f"{completeness_score}"
            )

        with col2:
            st.metric(
                "Anggaran",
                f"{budget_score}"
            )

        with col3:
            st.metric(
                "Konsistensi",
                f"{consistency_score}"
            )

        with col4:
            st.metric(
                "Bahasa",
                f"{language_score}"
            )

        st.divider()

        st.subheader("🏆 Skor Akhir")

        st.progress(final_score / 100)

        st.success(
            f"Skor Akhir: {final_score}/100 "
            f"({get_category(final_score)})"
        )

        st.divider()

        # =========================
        # DETAIL ANALISIS
        # =========================

        tab1, tab2, tab3 = st.tabs(
            [
                "📄 Kelengkapan",
                "💰 Anggaran",
                "🤖 Review AI"
            ]
        )

        with tab1:
            st.markdown(section_report)

        with tab2:
            st.markdown(budget_report)

        with tab3:

            st.subheader("Review AI")

            st.write(ai_result["review"])

            st.subheader("Saran Perbaikan")

            for saran in ai_result["suggestions"]:
                st.write(f"• {saran}")

        # =========================
        # LAPORAN NILAI
        # =========================

        score_report = generate_score_report(
            completeness_score,
            budget_score,
            consistency_score,
            language_score,
            final_score
        )

        st.divider()

        st.subheader("📝 Ringkasan Penilaian")

        st.markdown(score_report)